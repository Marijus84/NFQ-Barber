<?php

namespace App\Controllers;

class HomeController {

  public function home()
  {

    unset($_SESSION['update']);
    unset($_SESSION['result']);

    return view('index');

  }
}




 ?>
