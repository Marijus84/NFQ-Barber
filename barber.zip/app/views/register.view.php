<?php require('partials/header.php');?>

  <?php $retVal = (isset($_SESSION['user'])) ? $text = "Redaguokite vizitą" : $text = "Registruokites vizitui" ; ?>

  <h1 class="py-4 text-center"><?= $text ?></h1>

  <div class="py-4 mx-3 text-center">
    Pasirinkite dieną ir/arba specialistą, pas kurį norite apsilankyti. Galima tik viena aktyvi registracija!
  </div>

  <div class="row justify-content-center">
    <div class="col-md-7 my-3">
      <form action="register" method="POST" class="mx-3" enctype="multipart/form-data">
        <?php $name = isset($_SESSION['userName']) ? $_SESSION['userName'] : null;
          $lastname = isset($_SESSION['userLastname']) ? $_SESSION['userLastname'] : null;
          $date = isset($_SESSION['date']) ? $_SESSION['date'] : null; ?>
        <input class="form-control my-4" name="name" type="text" placeholder="Your name" value = "<?= $name ?>"  required>
        <input class="form-control my-4" name="lastname" type="text" placeholder="Your lastname" value = "<?= $lastname ?>" required>

            <label for="Speed" >Specialistai</label>
            <select required id="Barbers" name="barber" class="form-control mb-4">
              <?php foreach ($barbers as $barber) { ?>
                  <option value="<?=$barber->name?>"><?= $barber->name?></option>
              <?php } ?>
            </select>

        <div class="form-group">
           <label >Numatomo vizito data</label>
           <input type="date" name="day" value = "<?= $date ?>" max=<?= date("Y-m-d", strtotime("+2 months")); ?>
                  min=<?= date("Y-m-d"); ?> class="form-control" required>
        </div>

        <hr class="mb-1 my-5">
        <div class="row justify-content-center">
          <div class="col-md-8 justify-content-center">
            <button class="btn btn-primary btn-lg btn-block mb-5  " type="submit">Ieškoti laisvų laikų</button>
          </div>
        </div>

      </form>

      <?php if (isset($times)) { ?>

      <h2 class="py-4">Galimi laikai:</h2>
      <table class="table tbl">
        <thead>
          <tr>
            <th scope="col">Data</th>
            <th scope="col">Laikas</th>
            <th scope="col">Specialistas</th>
            <th scope="col">Rezervuoti</th>
          </tr>
        </thead>
        <tbody>

          <?php if (isset($reserved)) { ?>
            <?php foreach ($times as $key => $slot) { ?>
              <?php foreach ($reserved as $time) { ?>
                <?php if ($time->time == $slot){
                  unset($times[$key]);?>
          <?php }
              }
            } ?>
    <?php } ?>

        <?php foreach ($times as $slot) { ?>
          <tr>
            <td class="align-middle"><?= $_SESSION['date'] ?></td>
            <td class="align-middle"><?= $slot ?></td>
            <td class="align-middle"><?= $_SESSION['barber'] ?></td>
            <td>
              <form action="submit" method="POST">
                <input hidden class="form-control" name="time" type="text" value = "<?= $slot ?>">
                <button type="submit" class="btn btn-danger col-md-12">Pasirinkti laiką</button>
              </form>
            </td>
          </tr>
        <?php } ?>
      </tbody>
    </table>
  <?php  } ?>
    </div>
  </div>


<?php require('partials/footer.php') ?>
