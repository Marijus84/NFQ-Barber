<?php require('partials/header.php');  ?>

  <?php if (isset($_SESSION['update'])) {?>

  <div class="alert alert-success text-center  " role = "alert">
    <h2>Jūsų redagavimas pavyko. Rezervacijos ID: <?= $_SESSION['reservation_id']  ?><br>
    <?= $_SESSION['date'] .' '. $_SESSION['time'] .' pas specialistą vardu '. $_SESSION['barber'] ?></h2>
    <h3>Rezervacijos ID reikalingas norint atšaukti vizitą. <br></h3>
  </div>

  <div class="row text-center">
    <button onclick="location.href='/';" class="btn btn-success col-md-4 my-5 mx-5">Į pradinį puslapį</button>
  </div>

  <?php }

    else if ($_SESSION['result'] == 'Allowed') { ?>

    <div class="alert alert-success text-center  " role = "alert">
      <h2>Jūsų rezervacijos ID: <?= $_SESSION['reservation_id']  ?><br>
      <?= $_SESSION['date'] .' '. $_SESSION['time'] .' pas specialistą vardu '. $_SESSION['barber'] ?></h2>
      <h3>Rezervacijos ID reikalingas norint atšaukti vizitą. <br></h3>
    </div>

    <div class="row text-center">
      <button onclick="location.href='/';" class="btn btn-success col-md-4 my-5 mx-5">Į pradinį puslapį</button>
    </div>

  <?php }

    else if ($_SESSION['result'] == 'notAllowed') { ?>

      <div class="alert alert-danger text-center  " role = "alert">
        <h2>Jūs jau turite galiojančią rezervaciją: <br>
        <?= $_SESSION['date'] .' '. $_SESSION['time'] .' pas specialistą vardu '. $_SESSION['barber'] ?></h2>
      </div>

      <div class="row text-center">
        <button onclick="location.href='/index.php/register';" class="btn btn-danger col-md-4 my-5 mx-5">Grįžti</button>
      </div>

    <?php }

    else if ($_SESSION['result'] == 'deleted') { ?>

      <div class="alert alert-success text-center  " role = "alert">
        <h2>Jūs sėkmingai ištrynėte rezervaciją</h2>
      </div>

      <div class="row text-center">
        <button onclick="location.href='/';" class="btn btn-info col-md-4 my-5 mx-5">Į pradinį puslapį</button>
      </div>

    <?php }

    else if ($_SESSION['result'] == 'notDeleted') { ?>

      <div class="alert alert-danger text-center  " role = "alert">
      <h2>Rezervacijos ištrinti nepavyko</h2>
      </div>

      <div class="row text-center">
        <button onclick="location.href='/';" class="btn btn-info col-md-4 my-5 mx-5">Į pradinį puslapį</button>
      </div>

    <?php } ?>


<?php require('partials/footer.php') ?>
