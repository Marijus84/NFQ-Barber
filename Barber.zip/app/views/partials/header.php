<?php
if (isset($_POST['userName'])) {
  $cookie_name = "name";
  $cookie_value = '';
  $exp = time() + (86400 * 30);
  setcookie($cookie_name, $cookie_value, $exp, "/");

  $cookie_name = "lastname";
  $cookie_value = '';
  setcookie($cookie_name, $cookie_value, $exp, "/");
}

if(isset($_COOKIE['name'])) {
    $_SESSION['userName'] = $_COOKIE['name'];
    $_SESSION['userLastname'] = $_COOKIE['lastname'];
    echo $_SESSION['userLastname'];
}
setlocale(LC_ALL, 'lt_LT.UTF-8');
?>


<!DOCTYPE html>
<html lang="lt" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Auksinės žirklės</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="/public/css/style.css">
    <script
  src="https://code.jquery.com/jquery-3.3.1.js"
  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src = "/public/js/my.js"></script>

  </head>
  <body>

  <header>
    <div class="container">
      <nav>
        <div class="row">
          <div class="col-md-3 logo">
            <a href = "/"><img src="/public/img/logo.jpg" alt="logo" class="pull-left"></a>
          </div>
          <div class="col-md-9">
            <ul class="pull-right">
              <?php if (!isset($_SESSION['user']))
              { ?>
                <li><a href="/index.php/register">Registruotis</a></li>
                <li><a href="/index.php/cancel">Atšaukti registraciją</a></li>
        <?php  } ?>

              <li><a href="/index.php/login">Darbuotojams</a></li>
              <?php if (isset($_SESSION['user']))
              { ?>
                <li><a href="/index.php/top">Geriausi klientai</a></li>
                <li><a href="/index.php/disconnect">Atsijungti</a></li>
        <?php } ?>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  </header>
  <main>
