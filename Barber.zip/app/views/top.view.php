<?php require('partials/header.php');

  if (!isset($_SESSION['user'])){
   header('Location: /');}  ?>

  <div class="row justify-content-center">
    <div class="col-md-8 my-3 justify-content-center">
    <h2 class="py-4">Geriausi klientai:</h2>

      <table class="table tbl">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Vardas</th>
            <th scope="col">Pavardė</th>
            <th scope="col">Apsilankymų</th>
          </tr>
        </thead>
        <tbody>

        <ul class="pagination justify-content-center">
          <?php for ($i=1; $i <=$pageCount ; $i++): ?>
          <?php if ($page == $i){ ?>
            <li class="page-item active"><a class="page-link" href="index.php/top?page=<?php echo $i?>"><?php echo $i ?></a></li>
          <?php }
                else{   ?> <li class="page-item"><a class="page-link" href="index.php/top?page=<?php echo $i?>"><?php echo $i ?></a></li>
              <?php }?>
            <?php endfor; ?>
          </ul>

        <?php for ($j=1; $j <=10; $j++) { ?>
          <?php if (isset($list[$offset+$j])){ ?>
            <tr class="navy">
            <td><?= $list[$offset+$j]['id_c'] ?></td>
            <td><?= $list[$offset+$j]['name'] ?></td>
            <td><?= $list[$offset+$j]['lastname'] ?></td>
            <td><?= $list[$offset+$j]['visits_count'] ?></td>
            </tr>
          <?php }
          } ?>

        </tbody>
      </table>
    </div>
  </div>


<?php require('partials/footer.php') ?>
