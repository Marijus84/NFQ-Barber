<?php

$router->get('',  'HomeController@home' );
$router->get('register',  'ReservationsController@create' );
$router->post('register', 'ReservationsController@list');
$router->post('submit', 'ReservationsController@store');
$router->get('result', 'ReservationsController@result');
$router->get('cancel', 'ReservationsController@cancel');
$router->post('delete', 'ReservationsController@destroy');
$router->get('login', 'BarbersController@login');
$router->post('logedView', 'BarbersController@auth');
$router->get('logedView', 'BarbersController@byPass');
$router->get('disconnect', 'BarbersController@disconnect');
$router->get('top', 'ClientsController@list');
$router->post('filter', 'BarbersController@list');
$router->post('back', 'BarbersController@back');

 ?>
