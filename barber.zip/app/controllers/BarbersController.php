<?php

namespace App\Controllers;
use App\Models\Barber;
use Carbon\Carbon;
use App\Models\Reservation;


class BarbersController {

  public function back()
  {

    return view('loged');

  }

  public function login()
  {

    return view('login');

  }

  public function auth()
  {

    $args['name'] = $_POST['name'];
    $pass =  Barber::login($args);

    if ($pass[0]->password == strtoupper(md5($_POST['password']))) {

      $_SESSION['user'] = true;

      $barbers = Barber::All();

      return view('loged', ['barbers' => $barbers ]);

    }

    else {
      echo "Neteisingi prisijungimo duomenys. Bandykite iš naujo";
    }
  }


  public function byPass()
  {

    $barbers = Barber::All();

    return view('loged', ['barbers' => $barbers ]);

  }


  public function disconnect()
  {

    unset($_SESSION['user']);
    return view('index');

  }


  public function list()
  {

    if(isset($_POST['today'])){
      $dt = Carbon::now();
      $args['visit_date'] = $dt->toDateString();
    }

    elseif (isset($_POST['tomorrow'])) {
      $dt = Carbon::tomorrow();
      $args['visit_date'] = $dt->toDateString();
    }

    elseif (isset($_POST['day'])){
      $args['visit_date'] = $_POST['day'];

    }

    else {
      echo "date not set";
    }

    $_SESSION['date'] = $args['visit_date'];

    $_SESSION['barber'] = $_POST['barber'];

    $reserved = Reservation::WhereFullJoin($args);
    $barbers = Barber::All();

  return view('loged', ['reserved' => $reserved,
                          'barbers' => $barbers]);

  }

}

 ?>
