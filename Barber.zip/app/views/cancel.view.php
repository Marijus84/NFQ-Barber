<?php require('partials/header.php'); ?>

<h1 class="py-4 text-center">Vizito atšaukimas</h1>

  <div class="py-4 mx-3 text-center">
    Įveskite Jūsų vardą, pavardę ir vizito ID
  </div>

  <div class="row justify-content-center">
    <div class="col-md-7 my-3">
      <form action="index.php/delete" method="POST" class="mx-3" enctype="multipart/form-data">
        <?php $name = isset($_SESSION['userName']) ? $_SESSION['userName'] : null;
          $lastname = isset($_SESSION['userLastname']) ? $_SESSION['userLastname'] : null;
          $id = isset($_SESSION['reservation_id']) ? $_SESSION['reservation_id'] : null;?>

        <input class="form-control my-4" name="name" type="text" placeholder="Your name" value = "<?= $name ?>"  required>
        <input class="form-control my-4" name="lastname" type="text" placeholder="Your lastname" value = "<?= $lastname ?>" required>
        <input class="form-control my-4" name="visit_id" type="number" placeholder="Visit Id" value = "<?= $id ?>" required>

        <hr class="mb-1 my-5">
        <div class="row justify-content-center">
          <div class="col-md-8 justify-content-center">
            <button class="btn btn-warning btn-lg btn-block mb-5  " type="submit">Pašalinti vizitą</button>
          </div>
        </div>
      </form>

<?php require('partials/footer.php') ?>
