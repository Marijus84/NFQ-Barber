<?php

namespace App\Models;

use App\Controllers\ReservationsController;
use App\Core\App;
use Carbon\Carbon;
use App\Models\Client;


class Reservation
{


  public static function insert($reservation)
  {

   $table = ['Reservations'];
   App::get('database')->insertNew($table, $reservation);
   $whereArgs['id_c'] = $reservation['client_id'];

   Client::updatePlus($whereArgs);

   return;

  }


  public static function delete($whereArg, $client)
  {

    $table = ['Reservations'];
    $return = App::get('database')->delete($table, $whereArg);

    if ($return = true) {

      Client::updateNeg($client);

    }

    return $return;
  }


  public static function edit($whereArgs)
  {

    $table = ['Reservations'];

    foreach ($whereArgs as $key => $value) {
      $arg = [];
      $arg[$key]= $value;

      $updated = App::get('database')->edition('Reservations', $_SESSION['reservation_id'], $arg);
    }

    return $updated;

  }


  public static function getId($whereArg)
  {

    $table = ['Reservations'];
    $column = ['id'];
    $id = App::get('database')->selectId($table, $column, $whereArg);

    return $id;

  }

  public static function WhereJoin($whereArgs)
  {

    $tables = ['Reservations', 'Barbers'];
    $join = ['barber_id', 'id_b'];
    $reserved = App::get('database')->selectJoin($tables, $whereArgs, $join);

    return $reserved;

  }


  public static function WhereFullJoin($whereArgs)
  {

    $tables = ['Reservations', 'Barbers', 'Clients'];
    $join = ['barber_id', 'id_c', 'client_id', 'id_b'];
    $reserved = App::get('database')->selectFullJoin($tables, $whereArgs, $join);

    return $reserved;

  }

  public static function slots()
  {

    $slots = [];
    return $slots;

  }


    public static function generateDateRange(Carbon $start_date, Carbon $end_date, $day, $slot_duration = 15)
  {
      $dates = [];
      $slots = $start_date->diffInMinutes($end_date)/$slot_duration;
      $dates[$start_date->toDateString()][]=$start_date->toTimeString();

      for($s = 1;$s <=$slots;$s++){

          $dates[$start_date->toDateString()][]=$start_date->addMinute($slot_duration)->toTimeString();

      }

      return $dates[$day];
  }

}
