<?php

namespace App\Models;

use App\Controllers\BarbersController;
use App\Core\App;


class Barber
{

  public static function All()
  {

    $barbers = App::get('database')->selectAll('Barbers');

    return $barbers;

  }


  public static function getId($whereArg)
  {

    $table = ['Barbers'];
    $column = ['id_b'];

    $id = App::get('database')->selectId($table, $column, $whereArg);

    return $id;

  }


  public static function login($args)
  {

    $result = App::get('database')->login('Barbers', 'password', $args);

    return $result;

  }

}
