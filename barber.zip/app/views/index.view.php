<?php require('partials/header.php'); ?>

<h1 class="text-center"> Auksinės Žirklės</h1>

<?php require('partials/footer.php') ?>
