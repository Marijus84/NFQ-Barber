<?php


class QueryBuilder
{

  protected $pdo;

  public function __construct($pdo)
  {
    $this->pdo = $pdo;
  }


  function selectAll($table)
  {
    $statement = $this->pdo->prepare("select * from $table");

    $statement->execute();

    return $statement->fetchAll(PDO::FETCH_CLASS);
  }


  function selectJoin($tables, $whereArgs, $join)
  {

    $sql = sprintf(
      'select * from %s a inner join %s b on b.%s = a.%s  where (%s) = (%s)',
      $tables[0],
      $tables[1],
      $join[1],
      $join[0],
      implode(', ' , array_keys($whereArgs)),
      ':' . implode(', :' , array_keys($whereArgs))
    );

    try {
      $statement = $this->pdo->prepare($sql);
      $statement->execute($whereArgs);
      return $statement->fetchAll(PDO::FETCH_CLASS);
    }

    catch (Exception $e){
      echo "Selecting from {$tables[0]}, {$tables[1]} did not succeed";
    }
  }


  function selectId($table, $column, $whereArgs)
  {

    $sql = sprintf(
      'select %s from %s where (%s) = (%s)',
      $column[0],
      $table[0],
      implode(', ' , array_keys($whereArgs)),
      ':' . implode(', :' , array_keys($whereArgs))
    );

    try {
      $statement = $this->pdo->prepare($sql);
      $statement->execute($whereArgs);
      return $statement->fetchAll(PDO::FETCH_CLASS);
    }

    catch (Exception $e){
      echo "Search for id error";
    }
  }


  function updatePos($table, $column, $whereArgs)
  {

    $sql = sprintf(
      'update %s set %s = %s +1 where (%s) = (%s)',
      $table[0],
      $column[0],
      $column[0],
      implode(', ' , array_keys($whereArgs)),
      ':' . implode(', :' , array_keys($whereArgs))
    );

    try {
      $statement = $this->pdo->prepare($sql);
      $statement->execute($whereArgs);
      return ;
    }

    catch (Exception $e){
      echo "Search for update error";
    }
  }


  function edition($table, $res_id, $whereArg)
  {
    $sql = sprintf(
      'update %s set %s = %s where %s = %s',
      $table,
      implode(', ' , array_keys($whereArg)),
      ':' . implode(', :' , array_keys($whereArg)),
      'id',
      $res_id
    );

    try {
      $statement = $this->pdo->prepare($sql);
      $statement->execute($whereArg);
      return;
    }

    catch (Exception $e){
      echo "Search for update error";
    }
  }


  function login($table, $column, $whereArgs)
  {

    $sql = sprintf(
      'select %s from %s where (%s) = (%s)',
      $column,
      $table,
      implode(', ' , array_keys($whereArgs)),
      ':' . implode(', :' , array_keys($whereArgs))
    );

    try {
      $statement = $this->pdo->prepare($sql);
      $statement->execute($whereArgs);
      return $statement->fetchAll(PDO::FETCH_CLASS);
    }

    catch (Exception $e){
      echo "Search for login error";
    }
  }


  function list($args)
  {

    $sql = sprintf(
      'select * from %s order by %s desc',
      $args['table'],
      $args['column']
        );

    try {
      $statement = $this->pdo->prepare($sql);
      $statement->execute($args);
      return $statement->fetchAll(PDO::FETCH_ASSOC);
    }

    catch (Exception $e){
      echo "Search for login error";
    }
  }


  function updateMinus($table, $column, $whereArgs)
  {

    $sql = sprintf(
      'update %s set %s = %s -1 where (%s) = (%s)',
      $table[0],
      $column[0],
      $column[0],
      implode(', ' , array_keys($whereArgs)),
      ':' . implode(', :' , array_keys($whereArgs))
    );

    try {
      $statement = $this->pdo->prepare($sql);
      $statement->execute($whereArgs);
      return;
    }

    catch (Exception $e){
      echo "Search for update error";
    }
  }


  function delete($table, $whereArgs)
  {

    $sql = sprintf(
      'delete from %s where (%s) = (%s)',
      $table[0],
      implode(', ' , array_keys($whereArgs)),
      ':' . implode(', :' , array_keys($whereArgs))
    );

    try {

      $statement = $this->pdo->prepare($sql);
      $statement->execute($whereArgs);
      return true;
    }

    catch (Exception $e){
      echo "Search for delete error";
    }
  }


  function insertNew($table, $parameters)
  {

    $sql = sprintf(
      'insert into %s (%s) values (%s)',
      $table[0],
      implode(', ' , array_keys($parameters)),
      ':' . implode(', :' , array_keys($parameters))
    );

    try {
      $statement = $this->pdo->prepare($sql);
      $statement->execute($parameters);
    }

    catch (Exception $e){
      echo "Insertion into {$table} did not succeed";
    }
  }

  function selectFullJoin($tables, $whereArgs, $join)
  {

    $sql = sprintf(
      'select * from %s a inner join %s b on b.%s = a.%s
                          inner join %s c on a.%s = c.%s where (%s) = (%s)',
      $tables[0],
      $tables[1],
      $join[3],
      $join[0],
      $tables[2],
      $join[2],
      $join[1],
      implode(', ' , array_keys($whereArgs)),
      ':' . implode(', :' , array_keys($whereArgs))
    );

    try {
      $statement = $this->pdo->prepare($sql);
      $statement->execute($whereArgs);
      return $statement->fetchAll(PDO::FETCH_CLASS);
    }

    catch (Exception $e){
      echo "Selecting from {$tables[0]}, {$tables[1]} did not succeed";
    }
  }
}

 ?>
