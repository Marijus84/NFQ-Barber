<?php

namespace App\Controllers;
use App\Models\Client;


class ClientsController {

  public function list()
  {

  $list = Client::getList();

  $perPage = 10;
  $page = 1;

  if (array_key_exists("page",$_GET)){
   $page = $_GET["page"];
  }

  $offset = $page * $perPage - $perPage;
  $pageCount = ceil(count($list)/$perPage);

  return view('top', ['list' => $list,
                      'offset' => $offset,
                      'page' => $page,
                      'pageCount' => $pageCount]);
  }

}




 ?>
