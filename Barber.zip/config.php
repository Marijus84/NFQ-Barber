<?php
return [
  'database' => [
    'name' => 'barber',
    'username' => 'romanovas_2',
    'password' => 'Tjenairas1',
    'connection' => 'mysql:host=127.0.0.1',
    'options' => [
      PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]
  ]
];

 ?>
