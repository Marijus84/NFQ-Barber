<?php require('partials/header.php'); ?>

<h1 class="py-4 text-center">Registruokites vizitui</h1>

<?php require('partials/footer.php') ?>
