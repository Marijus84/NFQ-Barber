<?php

namespace App\Models;

use App\Controllers\ClientsController;
use App\Core\App;
use App\Models\Reservation;

class Client
{

  public static function ifAllowed($whereArgs)
  {

    $tables = ['Reservations', 'Clients'];
    $join = ['client_id', 'id_c'];
    $reserved = App::get('database')->selectJoin($tables, $whereArgs, $join);

    return $reserved;

  }


  public static function updatePlus($whereArgs)
  {

    $tables = ['Clients'];
    $column = ['visits_count'];
    App::get('database')->updatePos($tables, $column, $whereArgs);

  }

  public static function updateNeg($whereArgs)
  {

    $tables = ['Clients'];
    $column = ['visits_count'];
    App::get('database')->updateMinus($tables, $column, $whereArgs);

    return;

  }


  public static function getId($whereArg)
  {

    $table = ['Clients'];
    $column = ['id_c'];

    $id = App::get('database')->selectId($table, $column, $whereArg);

    if (empty($id)){

    App::get('database')->insertNew($table, $whereArg);
    $id = App::get('database')->selectId($table, $column, $whereArg);

    }

    return $id;
  }


  public static function getList()
  {

    $args['table'] = 'Clients';
    $args['column'] = 'visits_count';

    $list = App::get('database')->list($args);

    return $list;

  }
}
