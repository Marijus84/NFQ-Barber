<?php

$router->get('',  'HomeController@home' );
$router->get('index.php/register',  'ReservationsController@create' );
$router->post('index.php/register', 'ReservationsController@list');
$router->post('index.php/submit', 'ReservationsController@store');
$router->get('index.php/result', 'ReservationsController@result');
$router->get('index.php/cancel', 'ReservationsController@cancel');
$router->post('index.php/delete', 'ReservationsController@destroy');
$router->get('index.php/login', 'BarbersController@login');
$router->post('index.php/logedView', 'BarbersController@auth');
$router->get('index.php/logedView', 'BarbersController@byPass');
$router->get('index.php/disconnect', 'BarbersController@disconnect');
$router->get('index.php/top', 'ClientsController@list');
$router->post('index.php/filter', 'BarbersController@list');
$router->post('index.php/back', 'BarbersController@back');

 ?>
