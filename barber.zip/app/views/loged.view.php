<?php require('partials/header.php');  ?>

<?php if ($_SESSION['user']){ ?>
  <h3 class="py-4 text-center" id = "text">Parinkite kurios dienos ir kurio specialisto vizitus norite matyti:</h3>


    <div class="row justify-content-center">
      <div class="col-md-7 my-3">
        <form action="filter" method="POST" class="mx-3" enctype="multipart/form-data">
          <?php $date = isset($_SESSION['date']) ? $_SESSION['date'] : null; ?>

              <label for="Speed" >Specialistas</label>
              <select required id="Barbers" name="barber" class="form-control mb-3">
                <?php foreach ($barbers as $barber) { ?>
                    <option value="<?=$barber->name?>"><?= $barber->name?></option>
                <?php } ?>
              </select>

          <h3 class="py-4 text-center">Diena</h3>
          <div class="row justify-content-center">
            <div class="col-md-8 justify-content-center">
              <button class="btn btn-success btn-lg btn-block mb-1" name = "today"  value="today" type="submit">Šiandien</button>
            </div>
          </div>

          <div class="row justify-content-center">
            <div class="col-md-8 justify-content-center">
              <button class="btn btn-success btn-lg btn-block mb-3" name = "tomorrow"  value="tomorrow" type="submit">Rytoj</button>
            </div>
          </div>

          <div class="form-group">
            <label >Arba pasirinkite tikslią datą</label>
            <input type="date" name="day" value = "<?= $date ?>" max=<?= date("Y-m-d", strtotime("+2 months")); ?>
            min=<?= date("Y-m-d", strtotime("-2 months")); ?> class="form-control" >
          </div>

          <hr class="mb-1 my-5">
          <div class="row justify-content-center">
            <div class="col-md-8 justify-content-center">
              <button class="btn btn-primary btn-lg btn-block mb-5  " type="submit">Ieškoti</button>
            </div>
          </div>
        </form>
      </div>
    <div class="col-md-10 my-3" id = "hide">

    <?php if (isset($reserved)) { ?>
    <h2 class="py-4">Rezervuota:</h2>
      <table class="table tbl">
        <thead>
          <tr>
            <th scope="col">Data</th>
            <th scope="col">Laikas</th>
            <th scope="col">Specialistas</th>
            <th scope="col">Vardas</th>
            <th scope="col">Pavardė</th>
            <th scope="col">Nuolaida</th>
            <th scope="col">Trinti</th>
          </tr>
        </thead>
        <tbody>

        <?php foreach ($reserved as $time) { ?>
          <?php $_SESSION['userName'] = $time->name ?>
          <?php $_SESSION['userLastname'] = $time->lastname ?>
          <?php $_SESSION['reservation_id'] = $time->id ?>
          <?php $_SESSION['barber_id'] = $time->barber_id ?>
          <?php $_SESSION['client_id'] = $time->client_id ?>

            <tr id = "promotion">
              <td class="align-middle"><?= $_SESSION['date'] ?></td>
              <td class="align-middle"><?= $time->time ?></td>
              <td class="align-middle"><?= $_SESSION['barber'] ?></td>
              <td class="align-middle"><?=  $time->name ?></td>
              <td class="align-middle"><?=  $time->lastname ?></td>
              <td class="align-middle" >

               <?php if (($time->visits_count % 5 == 0) && ($time->visits_count >0)) { ?>
                  <script type="text/javascript">
                    getFeed();
                  </script>
                <?="Nuolaida 10%!";
               } ?> </td>
              <td>

              <form action="register"  method="GET">
                <button class="btn btn-warning btn-lg btn-block mb-2" id="livePost" type="submit">Redaguoti</button>
              </form>

              <form action="delete" method="POST">
                <input hidden class="form-control" name="time" type="text" value = "<?= $time->time ?>">
                <input hidden class="form-control" name="client_id" type="text" value = "<?= $time->client_id ?>">
                <button type="submit" class="btn btn-danger col-md-12">Trinti</button>
              </form>
            </td>
          </tr>
        <?php
          }
         ?>
         <?php
        } ?>

        </tbody>
      </table>
    </div>
  </div>

  <?php } ?>

<?php require('partials/footer.php') ?>
