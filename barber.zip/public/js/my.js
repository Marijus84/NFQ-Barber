function getFeed() {
  var element = document.getElementById("promotion");
  element.classList.toggle("green");
  for (let   i = 0; i < 10; i++) {
    $('#promotion').animate({
      opacity: 0.3,
    }, 1000);
    $('#promotion').animate({
      opacity: 1,
    }, 1000);

  }
}
