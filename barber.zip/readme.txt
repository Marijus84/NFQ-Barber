Trumpa portalo "Auksinės žirklės" naudojimo instrukcija.

Portalas skirtas dviejų tipų lankytojams: paprasti svečiai ir kirpyklos darbutojai, kurie gali prisijungti ir matyti daugiau informacijos. 

Paprasti lankytojai pagrindiniame lange turi du meniu pasirinkimus: Registruotis(vizitui), Atšaukti jau esamą rezervaciją.
Nuėję į registracijos dalį, klientai turi įvesti vardą, pavardę, pasirinkti kirpėją ir vizito datą. Pagal parinktis atliekama užklausa ir išvedamas sąrašas galimų laikų. Klientas gali pasirinkti vieną iš laikų. Pasiinkus laiką, gaunamas patvirtinimas ir užsakymo ID, kuris reikalingas atšaukimo atveju. 
Jei klientas jau turi aktyvią ateityje numatytą rezervaciją - jis gauna apie tai pranešimą ir negali registruotis antram vizitui. 
Paspaudus nuorodą, kad atšaukti rezervaciją, klientas turi pateikti vardą, pavardę ir iD. Sėkmingai atšaukus rezervaciją, gaunamas pranešimas. 

Kirpyklos darbuotojai gali rinktis parinktį meniu Darbuotojams ir prisijungti suvesdami savo vardą ir slaptažodį. Kirpykloje yra 5 kirpėjai. Jų slaptažodžiai yra nuo 'admin1' iki 'admin5'. Pvz.: Dalia turi slaptažodį admin1. 
Prisijungęs darbuotojas iškart gali filtruoti vizitus: pagal datą ir specialistą. Klientai, kurių vizitas bus jubiliejinis (į, ą“ ir t.t.) sąraše pažymėti prierašu, kad jiems reikalinga nuolaida.  
Atlikus paiešką, galima iškart kiekvieną laiką ištrinti arba keisti. 
Taipogi darbuotojai gali pasirinkti meniu parinktį su Geriausiais klientais ir matyti puslapiuotą sąrašą su klientais, kurie rūšiuojami nuo daugiausiai apsilankymų turinčių. 
Darbuotojas gali atsijungti paspaudęs nuorodą - atsijungti. 


