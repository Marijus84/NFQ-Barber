<?php require('partials/header.php');  ?>
  <?php if (isset($_SESSION['user'])) {
    header('Location: /logedView');
  } ?>

  <div class="row py-5 justify-content-center">
      <div class="col-md-8">
          <div class="card my-4">
              <div class="card-header">Prisijungimas </div>
                <div class="card-body">
                  <form method="POST" action="logedView">
                      <div class="form-group row">
                          <label for="name" class="col-sm-4 col-form-label text-md-right">Vardas<span class="star-small">*</span></label>

                          <div class="col-md-6">
                              <input id="name" type="text" class="form-control" name="name" required autofocus>
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="password" class="col-md-4 col-form-label text-md-right">Slaptažodis<span class="star-small">*</span></label>
                          <div class="col-md-6">
                              <input id="password" type="password" class="form-control" name="password" required>
                          </div>
                      </div>

                      <div class="form-group row mb-0">
                          <div class="col-md-8 offset-md-4">
                              <button type="submit" class="btn btn-primary">
                                  Prisijungti
                              </button>
                          </div>
                      </div>
                  </form>
              </div>
          </div>
      </div>
  </div>



<?php require('partials/footer.php') ?>
