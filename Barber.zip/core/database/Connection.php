<?php

class Connection
{

public static function make($config)
  {
    var_dump($config['connection'].';dbname='.$config['name'],
    $config['username'],$config['password'],
    $config['options']);
        try {

          return new PDO(
            $config['connection'].';dbname='.$config['name'],
            $config['username'],$config['password'],
            $config['options']
          );
        }

        catch(PDOException $e){
          { print $e->getMessage(); }
      }
    }
  }

 ?>
