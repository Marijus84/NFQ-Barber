<?php

namespace App\Controllers;
use App\Models\Barber;
use App\Models\Client;
use App\Models\Reservation;
use Carbon\Carbon;

class ReservationsController {

  public function create()
  {

    $barbers = Barber::All();
    return view('register', ['barbers' => $barbers ]);

  }


  public function list()
  {

  $times = [];

  if (isset($_POST)) {

    $_SESSION['userName'] = $_POST['name'];
    $_SESSION['userLastname'] = $_POST['lastname'];

    $_SESSION['date'] = $_POST['day'];
    $_SESSION['barber'] = $_POST['barber'];

    $start = new \DateTime("{$_POST['day']} 09:00");
    $finish = new \DateTime("{$_POST['day']} 17:45");
    $start = Carbon::instance($start);
    $finish = Carbon::instance($finish);
    $times = Reservation::generateDateRange($start, $finish, $_POST['day']);
  }

  $whereArgs['visit_date'] = $_POST['day'];
  $whereArgs['name'] = $_POST['barber'];

  $reserved = Reservation::WhereJoin($whereArgs);
  $barbers = Barber::All();

  return view('register', ['reserved' => $reserved,
                          'barbers' => $barbers,
                          'times' => $times]);

  }


  public function store()  {

  if (isset($_SESSION['user'])) {

    $whereArg['barber_id'] = $_SESSION['barber_id'];
    $whereArg['client_id'] = $_SESSION['client_id'];
    $whereArg['visit_date'] = $_SESSION['date'];
    $whereArg['time'] = $_POST['time'];

    Reservation::edit($whereArg);

    $_SESSION['update'] = true;
    $_SESSION['time'] = $_POST['time'];

    return view('result');
    }


    $whereArg['name'] = $_SESSION['userName'];
    $whereArg['lastname'] = $_SESSION['userLastname'];

    $barber['name'] = $_SESSION['barber'];
    $_SESSION['time'] = $_POST['time'];

    $reserved = Client::ifAllowed($whereArg);
    foreach ($reserved as $reservation) {
      if (($reservation->visit_date == $_SESSION['date']) && ($reservation->time < $_POST['time'])
          || ($reservation->visit_date > $_SESSION['date'])) {
        $_SESSION['result'] = 'notAllowed';
        header('Location: /result');
      }
    }

    $client_id = Client::getId($whereArg);
    $barber_id = Barber::getId($barber);
    $reservation['client_id'] = $client_id[0]->id_c;
    $reservation['barber_id'] = $barber_id[0]->id_b;
    $reservation['visit_date'] = $_SESSION['date'];
    $reservation['time'] = $_POST['time'];

    Reservation::insert($reservation);
    $res_id = Reservation::getId($reservation);
    $_SESSION['reservation_id'] = $res_id[0]->id;
    $_SESSION['result'] = 'Allowed';

    header('Location: /result');

  }


  public function result(){

    return view('result');

  }


  public function cancel(){

    return view('cancel');

  }


  public function destroy(){

    if (isset($_SESSION['user'])) {
      $args['client_id'] = $_POST['client_id'];
      $argClient['id'] = $_POST['client_id'];
      $res_id = Reservation::getId($args);
      $res['reservation_id'] = $res_id[0]->id;

      $deleteArg['id'] = $res['reservation_id'];

      $result = Reservation::delete($deleteArg, $argClient);

      $_SESSION['result'] = 'deleted';

      header('Location: /result');
    }


    $_SESSION['result'] = 'notDeleted';
    $whereArg['name'] = $_POST['name'];
    $whereArg['lastname'] = $_POST['lastname'];

    $client_id = Client::getId($whereArg);

    $args['client_id'] = $client_id[0]->id_c;
    $argClient['id'] = $client_id[0]->id_c;
    $res_id = Reservation::getId($args);

    $res['reservation_id'] = $res_id[0]->id;

    if ($res['reservation_id'] == $_POST['visit_id']) {
      $deleteArg['id'] = $_POST['visit_id'];

      $result = Reservation::delete($deleteArg, $argClient);

      $_SESSION['result'] = 'deleted';

      header('Location: /result');
    }

    header('Location: /result');
  }
}

 ?>
